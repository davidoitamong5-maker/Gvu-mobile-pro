package com.gvu.mobilepro

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF101827)
private val Panel = Color(0xFF1B2638)
private val Green = Color(0xFF31D69A)
private val Muted = Color(0xFF9AA9BD)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GvuDashboard() }
    }
}

@Composable
fun GvuDashboard() {
    var botEnabled by remember { mutableStateOf(false) }
    var risk by remember { mutableFloatStateOf(1f) }
    var maxTrades by remember { mutableFloatStateOf(3f) }
    var status by remember { mutableStateOf("Demo preview — trading engine not connected") }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Navy, surface = Panel, primary = Green,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Column(
            Modifier.fillMaxSize().background(Navy).verticalScroll(rememberScrollState()).padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text("GVU MOBILE PRO", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Text("MT5 remote dashboard", color = Muted, fontSize = 12.sp)
                }
                Surface(color = Color(0xFF563A20), shape = RoundedCornerShape(50)) {
                    Text("NOT CONNECTED", Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        color = Color(0xFFFFC477), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }

            Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("ACCOUNT OVERVIEW", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Metric("Balance", "—")
                        Metric("Equity", "—")
                        Metric("Today's P/L", "—")
                    }
                    Text("Values appear after a secure MT5 bridge is connected.", color = Muted, fontSize = 11.sp)
                }
            }

            Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("ROBOT CONTROL", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically) {
                        Text(if (botEnabled) "Trading enabled" else "Trading paused", fontWeight = FontWeight.SemiBold)
                        Switch(checked = botEnabled, onCheckedChange = {
                            botEnabled = it
                            status = if (it) "Local preview switch changed; no live command sent"
                                     else "Paused in preview; no live command sent"
                        })
                    }
                    Text("Risk per trade: ${"%.1f".format(risk)}%", color = Muted)
                    Slider(value = risk, onValueChange = { risk = it }, valueRange = 0.25f..2f)
                    Text("Maximum open trades: ${maxTrades.toInt()}", color = Muted)
                    Slider(value = maxTrades, onValueChange = { maxTrades = it }, valueRange = 1f..5f, steps = 3)
                    Text(status, color = Color(0xFFFFC477), fontSize = 11.sp)
                }
            }

            Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("STRATEGY ENGINE", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    StrategyRow("Trend filter", "EMA 50/200 + ADX")
                    StrategyRow("Entries", "Pullback • Breakout/retest")
                    StrategyRow("Price action", "Liquidity sweep • BOS/CHOCH")
                    StrategyRow("Market mode", "Support/resistance • Range")
                    StrategyRow("Momentum check", "EMA 10/23 • RSI")
                    StrategyRow("Protection", "ATR stop • Daily loss limit")
                }
            }

            Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("OPEN POSITIONS", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text("No live positions available in preview mode.", color = Muted, fontSize = 12.sp)
                }
            }
            Text("Safety: this preview does not place orders. Live trading requires a secured VPS-side MT5 EA bridge, authentication and demo testing.",
                color = Muted, fontSize = 11.sp)
        }
    }
}

@Composable
private fun Metric(label: String, value: String) {
    Column {
        Text(label, color = Muted, fontSize = 11.sp)
        Text(value, color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun StrategyRow(label: String, detail: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        Text(detail, color = Muted, fontSize = 11.sp)
    }
}
