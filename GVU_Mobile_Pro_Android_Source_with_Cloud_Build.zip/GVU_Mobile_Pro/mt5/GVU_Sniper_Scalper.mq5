//+------------------------------------------------------------------+
//| GVU Sniper Scalper EA                                            |
//| MT5 Expert Advisor: M1 entry timing + M5 trend confirmation      |
//| Test on demo first. No strategy guarantees profits.               |
//+------------------------------------------------------------------+
#property strict
#property version   "1.00"
#property description "GVU Sniper Scalper: M1/M5 EMA confirmation, per-position cash target, risk controls."

#include <Trade/Trade.mqh>
CTrade trade;

input string          InpTradeSymbol          = "";          // Blank = chart symbol
input ENUM_TIMEFRAMES InpEntryTF              = PERIOD_M1;   // Entry timeframe
input ENUM_TIMEFRAMES InpTrendTF              = PERIOD_M5;   // Trend confirmation timeframe
input int             InpFastEMA              = 10;
input int             InpSlowEMA              = 23;
input double          InpLots                 = 0.01;        // Fixed lot size; start small
input int             InpMaxPositions         = 5;           // Maximum EA positions on symbol
input double          InpProfitTargetMoney    = 1.00;        // Close each position at this profit (account currency)
input int             InpMaxSpreadPoints      = 25;          // Maximum allowed spread, points
input int             InpATRPeriod            = 14;
input double          InpATRStopMultiplier    = 1.5;         // Initial stop-loss distance = ATR x multiplier
input double          InpDailyLossLimitPct    = 3.0;         // Stop new entries and close EA positions at daily loss limit
input ulong           InpMagic                = 16102026;
input int             InpDeviationPoints      = 10;
input bool            InpAllowBuy             = true;
input bool            InpAllowSell            = true;

string   tradeSymbol;
int      hFastEntry = INVALID_HANDLE;
int      hSlowEntry = INVALID_HANDLE;
int      hFastTrend = INVALID_HANDLE;
int      hSlowTrend = INVALID_HANDLE;
int      hATR       = INVALID_HANDLE;
datetime lastEntryBar = 0;
int      dayKey = -1;
double   dayStartEquity = 0.0;
bool     dailyStopHit = false;

// Use a terminal global variable so the daily reference survives EA restarts.
string DailyKeyName()
{
   return "GVU_DayStart_" + IntegerToString((long)AccountInfoInteger(ACCOUNT_LOGIN))
          + "_" + IntegerToString((long)InpMagic) + "_" + tradeSymbol;
}

int CurrentDayKey()
{
   MqlDateTime dt;
   TimeToStruct(TimeCurrent(), dt);
   return dt.year * 10000 + dt.mon * 100 + dt.day;
}

void RefreshDailyReference()
{
   int today = CurrentDayKey();
   string key = DailyKeyName();

   if(today != dayKey)
   {
      dayKey = today;
      dailyStopHit = false;
      if(GlobalVariableCheck(key))
      {
         double saved = GlobalVariableGet(key);
         // Store day key and equity together in two globals.
         string dateKey = key + "_date";
         if(GlobalVariableCheck(dateKey) && (int)GlobalVariableGet(dateKey) == today && saved > 0)
            dayStartEquity = saved;
         else
         {
            dayStartEquity = AccountInfoDouble(ACCOUNT_EQUITY);
            GlobalVariableSet(key, dayStartEquity);
            GlobalVariableSet(dateKey, today);
         }
      }
      else
      {
         dayStartEquity = AccountInfoDouble(ACCOUNT_EQUITY);
         GlobalVariableSet(key, dayStartEquity);
         GlobalVariableSet(key + "_date", today);
      }
   }
}

double NormalizeVolume(double lots)
{
   double minVol = SymbolInfoDouble(tradeSymbol, SYMBOL_VOLUME_MIN);
   double maxVol = SymbolInfoDouble(tradeSymbol, SYMBOL_VOLUME_MAX);
   double step   = SymbolInfoDouble(tradeSymbol, SYMBOL_VOLUME_STEP);
   if(step <= 0) return 0.0;

   lots = MathMax(minVol, MathMin(maxVol, lots));
   lots = MathFloor(lots / step + 1e-8) * step;
   int digits = 0;
   double s = step;
   while(digits < 8 && MathAbs(s - MathRound(s)) > 1e-8)
   {
      s *= 10.0;
      digits++;
   }
   return NormalizeDouble(lots, digits);
}

bool ReadValue(int handle, int shift, double &value)
{
   double buffer[];
   ArraySetAsSeries(buffer, true);
   if(CopyBuffer(handle, 0, shift, 1, buffer) != 1)
      return false;
   value = buffer[0];
   return true;
}

int CountOurPositions()
{
   int count = 0;
   for(int i = PositionsTotal() - 1; i >= 0; --i)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket == 0 || !PositionSelectByTicket(ticket)) continue;
      if(PositionGetString(POSITION_SYMBOL) == tradeSymbol &&
         (ulong)PositionGetInteger(POSITION_MAGIC) == InpMagic)
         count++;
   }
   return count;
}

void ManageProfitTargets()
{
   for(int i = PositionsTotal() - 1; i >= 0; --i)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket == 0 || !PositionSelectByTicket(ticket)) continue;
      if(PositionGetString(POSITION_SYMBOL) != tradeSymbol) continue;
      if((ulong)PositionGetInteger(POSITION_MAGIC) != InpMagic) continue;

      // Position profit + swap. Broker commission treatment can vary, so verify on demo.
      double netApprox = PositionGetDouble(POSITION_PROFIT) + PositionGetDouble(POSITION_SWAP);
      if(netApprox >= InpProfitTargetMoney)
      {
         if(!trade.PositionClose(ticket))
            Print("GVU: close failed for ticket ", ticket, "; retcode=", trade.ResultRetcode(),
                  " ", trade.ResultRetcodeDescription());
      }
   }
}

bool DailyLossLimitReached()
{
   if(InpDailyLossLimitPct <= 0 || dayStartEquity <= 0) return false;
   double equity = AccountInfoDouble(ACCOUNT_EQUITY);
   double lossPct = (dayStartEquity - equity) / dayStartEquity * 100.0;
   return (lossPct >= InpDailyLossLimitPct);
}

void CloseAllOurPositions()
{
   for(int i = PositionsTotal() - 1; i >= 0; --i)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket == 0 || !PositionSelectByTicket(ticket)) continue;
      if(PositionGetString(POSITION_SYMBOL) != tradeSymbol) continue;
      if((ulong)PositionGetInteger(POSITION_MAGIC) != InpMagic) continue;
      if(!trade.PositionClose(ticket))
         Print("GVU: emergency close failed for ticket ", ticket, "; retcode=", trade.ResultRetcode());
   }
}

bool IsNewEntryBar()
{
   datetime times[];
   ArraySetAsSeries(times, true);
   if(CopyTime(tradeSymbol, InpEntryTF, 0, 1, times) != 1) return false;
   if(times[0] != lastEntryBar)
   {
      lastEntryBar = times[0];
      return true;
   }
   return false;
}

bool SpreadOK()
{
   MqlTick tick;
   if(!SymbolInfoTick(tradeSymbol, tick)) return false;
   double point = SymbolInfoDouble(tradeSymbol, SYMBOL_POINT);
   if(point <= 0) return false;
   double spreadPoints = (tick.ask - tick.bid) / point;
   return spreadPoints <= InpMaxSpreadPoints;
}

// Entry: M1 fast/slow EMA crossover on the last closed candles,
// confirmed by M5 EMA direction. Stops are based on M1 ATR.
int GetSignal(double &atrValue)
{
   double fast1, fast2, slow1, slow2, trendFast, trendSlow;
   if(!ReadValue(hFastEntry, 1, fast1) ||
      !ReadValue(hFastEntry, 2, fast2) ||
      !ReadValue(hSlowEntry, 1, slow1) ||
      !ReadValue(hSlowEntry, 2, slow2) ||
      !ReadValue(hFastTrend, 1, trendFast) ||
      !ReadValue(hSlowTrend, 1, trendSlow) ||
      !ReadValue(hATR, 1, atrValue))
      return 0;

   bool crossUp   = (fast2 <= slow2 && fast1 > slow1);
   bool crossDown = (fast2 >= slow2 && fast1 < slow1);

   if(InpAllowBuy && crossUp && trendFast > trendSlow) return 1;
   if(InpAllowSell && crossDown && trendFast < trendSlow) return -1;
   return 0;
}

bool OpenPosition(int direction, double atrValue)
{
   double lots = NormalizeVolume(InpLots);
   if(lots <= 0) return false;

   MqlTick tick;
   if(!SymbolInfoTick(tradeSymbol, tick)) return false;

   int digits = (int)SymbolInfoInteger(tradeSymbol, SYMBOL_DIGITS);
   double point = SymbolInfoDouble(tradeSymbol, SYMBOL_POINT);
   int stopsLevel = (int)SymbolInfoInteger(tradeSymbol, SYMBOL_TRADE_STOPS_LEVEL);
   double minStopDistance = stopsLevel * point;
   double stopDistance = MathMax(atrValue * InpATRStopMultiplier, minStopDistance + 2 * point);
   if(stopDistance <= 0) return false;

   bool result = false;
   if(direction > 0)
   {
      double sl = NormalizeDouble(tick.ask - stopDistance, digits);
      result = trade.Buy(lots, tradeSymbol, 0.0, sl, 0.0, "GVU Sniper M1/M5 BUY");
   }
   else
   {
      double sl = NormalizeDouble(tick.bid + stopDistance, digits);
      result = trade.Sell(lots, tradeSymbol, 0.0, sl, 0.0, "GVU Sniper M1/M5 SELL");
   }

   if(!result)
      Print("GVU: order failed; retcode=", trade.ResultRetcode(), " ", trade.ResultRetcodeDescription());
   return result;
}

int OnInit()
{
   tradeSymbol = (InpTradeSymbol == "" ? _Symbol : InpTradeSymbol);
   if(!SymbolSelect(tradeSymbol, true))
   {
      Print("GVU: cannot select symbol ", tradeSymbol);
      return INIT_FAILED;
   }

   hFastEntry = iMA(tradeSymbol, InpEntryTF, InpFastEMA, 0, MODE_EMA, PRICE_CLOSE);
   hSlowEntry = iMA(tradeSymbol, InpEntryTF, InpSlowEMA, 0, MODE_EMA, PRICE_CLOSE);
   hFastTrend = iMA(tradeSymbol, InpTrendTF, InpFastEMA, 0, MODE_EMA, PRICE_CLOSE);
   hSlowTrend = iMA(tradeSymbol, InpTrendTF, InpSlowEMA, 0, MODE_EMA, PRICE_CLOSE);
   hATR       = iATR(tradeSymbol, InpEntryTF, InpATRPeriod);

   if(hFastEntry == INVALID_HANDLE || hSlowEntry == INVALID_HANDLE ||
      hFastTrend == INVALID_HANDLE || hSlowTrend == INVALID_HANDLE || hATR == INVALID_HANDLE)
   {
      Print("GVU: indicator initialization failed.");
      return INIT_FAILED;
   }

   trade.SetExpertMagicNumber(InpMagic);
   trade.SetDeviationInPoints(InpDeviationPoints);
   trade.SetTypeFillingBySymbol(tradeSymbol);

   RefreshDailyReference();
   Print("GVU Sniper Scalper initialized on ", tradeSymbol,
         ". Test on demo first. Target is account-currency units.");
   return INIT_SUCCEEDED;
}

void OnDeinit(const int reason)
{
   if(hFastEntry != INVALID_HANDLE) IndicatorRelease(hFastEntry);
   if(hSlowEntry != INVALID_HANDLE) IndicatorRelease(hSlowEntry);
   if(hFastTrend != INVALID_HANDLE) IndicatorRelease(hFastTrend);
   if(hSlowTrend != INVALID_HANDLE) IndicatorRelease(hSlowTrend);
   if(hATR       != INVALID_HANDLE) IndicatorRelease(hATR);
}

void OnTick()
{
   RefreshDailyReference();
   ManageProfitTargets();

   if(DailyLossLimitReached())
   {
      if(!dailyStopHit)
      {
         dailyStopHit = true;
         Print("GVU: daily loss limit reached. Closing EA positions and pausing entries until the next server day.");
      }
      CloseAllOurPositions();
      return;
   }

   if(dailyStopHit) return;
   if(!IsNewEntryBar()) return;
   if(!SpreadOK()) return;

   // On a hedging account, this can build up to InpMaxPositions.
   // On a netting account, multiple same-symbol orders merge into one position.
   int current = CountOurPositions();
   if(current >= InpMaxPositions) return;

   double atrValue = 0.0;
   int signal = GetSignal(atrValue);
   if(signal == 0 || atrValue <= 0) return;

   // Fill available slots on a fresh confirmed signal. Re-entry is evaluated only
   // once per new entry-timeframe candle, not on every tick.
   int slots = InpMaxPositions - current;
   for(int n = 0; n < slots; n++)
   {
      if(!OpenPosition(signal, atrValue)) break;
   }
}
