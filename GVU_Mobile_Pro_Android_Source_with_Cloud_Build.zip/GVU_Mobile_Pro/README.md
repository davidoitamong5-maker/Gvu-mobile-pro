# GVU Mobile Pro — Android starter project

This is the first Android dashboard prototype for the GVU trading system. It is **not a live trading APK** and it does not send orders.

## Current contents
- Native Android app using Kotlin and Jetpack Compose
- Account overview placeholders
- Preview-only robot enable/pause switch
- Adjustable risk and max-position UI controls
- Strategy overview

## Required architecture for live trading
The MQL5 Expert Advisor must run inside desktop MT5 on a Windows VPS or always-on PC. The Android app communicates with a secure backend/bridge hosted alongside the MT5 terminal. MT5 mobile does not execute Expert Advisors.

The bridge still needs to be implemented and tested. It should:
- authenticate each device with revocable tokens (never store broker passwords in the app)
- expose account, positions, P/L and EA status through HTTPS
- accept narrowly scoped commands such as pause/resume and approved input changes
- validate all commands server-side and log them
- never expose the MT5 terminal or broker credentials directly to the public internet

## Build
Open this folder in Android Studio (current stable version), allow Gradle sync, then Build > Build APK(s). The project has not been compiled or device-tested in this environment.

## Next information needed
1. Broker name and exact MT5 server name (do not send passwords).
2. Whether you have a Windows VPS already, or need to plan one.
3. Android phone model / Android version for device testing.

## Trading safety
The attached original EA is included as `mt5/GVU_Sniper_Scalper.mq5` for reference. It is the existing baseline, not the proposed multi-strategy upgrade. Run strategy tests and demo forward tests before live use. No profit is guaranteed.


## Build APK using GitHub Actions (phone-only route)
This repository includes `.github/workflows/build-apk.yml`.
1. Create a private GitHub repository and upload the contents of this folder.
2. Open the repository's **Actions** tab and run **Build GVU Mobile Pro APK** (or wait for the first push build).
3. Open the completed workflow run, find **Artifacts**, and download `GVU-Mobile-Pro-debug-APK`.
4. Extract the artifact and install `app-debug.apk` on Android. Android may ask you to allow installation from that browser/file manager.

This produces a debug APK for testing, not a Play Store release. The APK remains a dashboard preview until the secure MT5 bridge and upgraded EA are implemented. Do not connect it to a live account yet.
