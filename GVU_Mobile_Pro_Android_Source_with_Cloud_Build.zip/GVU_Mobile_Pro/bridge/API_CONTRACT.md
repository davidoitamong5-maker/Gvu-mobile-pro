# GVU MT5 Bridge — API contract draft

All endpoints must use HTTPS and bearer-token authentication. This is a contract draft only; no server is included yet.

- `GET /v1/status` — connection state, EA state, server timestamp
- `GET /v1/account` — balance, equity, currency, today's realized/unrealized P/L
- `GET /v1/positions` — ticket, symbol, side, volume, entry, SL, TP, floating P/L
- `POST /v1/bot/pause` — pause new entries
- `POST /v1/bot/resume` — resume entries only if daily risk lock is not active
- `PATCH /v1/settings` — allowlisted settings only (risk %, max positions, symbols)

The bridge must reject unauthenticated requests, validate every setting, rate-limit commands, maintain an audit log, and enforce the daily loss lock independently of the phone app.
